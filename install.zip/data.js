﻿// Initialized by Install-And-Scan.ps1 or server.py
window.FORENSIC_DASHBOARD_DATA = null;
